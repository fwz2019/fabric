package ecdsa

import (
	"crypto"
	"crypto/aes"
	"crypto/cipher"
	"crypto/elliptic"
	"crypto/internal/randutil"
	"crypto/sha512"
	"encoding/binary"
	"io"
	"math/big"
)

var intOne = new(big.Int).SetInt64(1)
var defUserID = []byte{
	0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38,
	0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38,
}

// SM2Prefix returns the prefix to hash.
func SM2Prefix(hashType crypto.Hash, userID []byte, pubKey crypto.PublicKey) []byte {
	if pub, ok := pubKey.(*PublicKey); ok {
		if params, ok := pub.Curve.(*elliptic.SM2CurveParams); ok {
			if userID == nil {
				userID = defUserID
			}
			l := uint16(len(userID) * 8)
			b := make([]byte, 2)
			binary.BigEndian.PutUint16(b, l)

			h := hashType.New()
			h.Write(b)
			h.Write(userID)
			h.Write(params.A.Bytes())
			h.Write(params.B.Bytes())
			h.Write(params.Gx.Bytes())
			h.Write(params.Gy.Bytes())
			h.Write(pub.X.Bytes())
			h.Write(pub.Y.Bytes())

			return h.Sum(nil)
		}
	}

	return nil
}

// SM2Sign signs a hash using the private key.
func SM2Sign(rand io.Reader, priv *PrivateKey, hash []byte) (r, s *big.Int, err error) {
	randutil.MaybeReadByte(rand)

	// Get min(log2(q) / 2, 256) bits of entropy from rand.
	entropylen := (priv.Curve.Params().BitSize + 7) / 16
	if entropylen > 32 {
		entropylen = 32
	}
	entropy := make([]byte, entropylen)
	_, err = io.ReadFull(rand, entropy)
	if err != nil {
		return
	}

	// Initialize an SHA-512 hash context; digest ...
	md := sha512.New()
	md.Write(priv.D.Bytes()) // the private key,
	md.Write(entropy)        // the entropy,
	md.Write(hash)           // and the input hash;
	key := md.Sum(nil)[:32]  // and compute ChopMD-256(SHA-512),
	// which is an indifferentiable MAC.

	// Create an AES-CTR instance to use as a CSPRNG.
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, nil, err
	}

	// Create a CSPRNG that xors a stream of zeros with
	// the output of the AES-CTR instance.
	csprng := cipher.StreamReader{
		R: zeroReader,
		S: cipher.NewCTR(block, []byte(aesIV)),
	}

	c := priv.PublicKey.Curve
	N := c.Params().N
	if N.Sign() == 0 {
		return nil, nil, errZeroParam
	}
	e := new(big.Int).SetBytes(hash)
	var k, rk, d1Inv *big.Int
	for {
		for {
			k, err = randFieldElement(c, csprng)
			if err != nil {
				r = nil
				s = nil
				return
			}

			r, _ = priv.Curve.ScalarBaseMult(k.Bytes())
			r.Add(e, r)
			r.Mod(r, N) // N != 0
			rk = new(big.Int).Add(r, k)
			if (r.Sign() != 0) && (rk.Cmp(N) != 0) {
				break
			}
		}

		d1Inv = new(big.Int).Add(intOne, priv.D)
		if in, ok := priv.Curve.(invertible); ok {
			d1Inv = in.Inverse(d1Inv)
		} else {
			d1Inv = fermatInverse(d1Inv, N) // N != 0
		}
		s = new(big.Int).Mul(r, priv.D)
		s.Sub(k, s)
		s.Mul(d1Inv, s)
		s.Mod(s, N) // N != 0
		if s.Sign() != 0 {
			break
		}
	}

	return
}

// SM2Verify verifies the signature.
func SM2Verify(pub *PublicKey, hash []byte, r, s *big.Int) bool {
	c := pub.Curve
	N := c.Params().N

	if r.Sign() <= 0 || s.Sign() <= 0 {
		return false
	}
	if r.Cmp(N) >= 0 || s.Cmp(N) >= 0 {
		return false
	}
	e := new(big.Int).SetBytes(hash)

	t := new(big.Int).Add(r, s)
	t.Mod(t, N)
	if t.Sign() == 0 {
		return false
	}

	var x, y *big.Int
	if opt, ok := c.(combinedMult); ok {
		x, y = opt.CombinedMult(pub.X, pub.Y, s.Bytes(), t.Bytes())
	} else {
		x1, y1 := c.ScalarBaseMult(s.Bytes())
		x2, y2 := c.ScalarMult(pub.X, pub.Y, t.Bytes())
		x, y = c.Add(x1, y1, x2, y2)
	}
	if x.Sign() == 0 && y.Sign() == 0 {
		return false
	}

	R := new(big.Int).Add(e, x)
	R.Mod(R, N)

	return R.Cmp(r) == 0
}
